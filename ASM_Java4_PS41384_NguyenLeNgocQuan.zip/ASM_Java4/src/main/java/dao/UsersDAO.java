package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import entity.Users;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class UsersDAO implements DAOInterface<Users, String> {
	@Override
	public List<Users> findAll() {
		List<Users> list = new ArrayList();
		SessionFactory factory = null;
		EntityManager manager = null;
		try {
			factory = XJPA.getSessionFactory();
			if (factory != null) {
				manager = factory.createEntityManager();
				manager.getTransaction().begin();
				Query query = manager.createQuery("from Users");
				list = query.getResultList();
				manager.getTransaction().commit();
				manager.close();
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Users findById(String id) {
		Users user = null;
		SessionFactory factory = null;
		EntityManager manager = null;
		try {
			factory = XJPA.getSessionFactory();
			if (factory != null) {
				manager = factory.createEntityManager();
				manager.getTransaction().begin();
				Query query = manager.createQuery("from Users u where u.id = :id");
				query.setParameter("id", id);
				user = (Users) query.getSingleResult();
				manager.getTransaction().commit();
				manager.close();
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
		}
		return user;
	}

	@Override
	public void create(Users t) {
		SessionFactory factory = null;
		Session manager = null;
		try {
			factory = XJPA.getSessionFactory();
			if (factory != null) {
				manager = factory.openSession();
				manager.getTransaction().begin();
				manager.persist(t);
				manager.getTransaction().commit();
				manager.close();
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
			e.printStackTrace();
		}
	}

	@Override
	public boolean deleteById(String id) {
		Users entity = this.findById(id);
		SessionFactory factory = null;
		EntityManager manager = null;
		try {
			factory = XJPA.getSessionFactory();
			if (factory != null) {
				manager = factory.createEntityManager();
				manager.getTransaction().begin();
				manager.remove(entity);
				manager.getTransaction().commit();
				manager.close();
				return true;
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
		}
		return false;
	}

	@Override
	public void update(Users t) {
		SessionFactory factory = null;
		EntityManager manager = null;
		try {
			factory = XJPA.getSessionFactory();
			if (factory != null) {
				manager = factory.createEntityManager();
				manager.getTransaction().begin();
				manager.merge(t);
				manager.getTransaction().commit();
				manager.close();
			}
		} catch (Exception e) {
			manager.getTransaction().rollback();
		}
	}

	public Users findByIdOrEmail(String idOrEmail) {
	    Users user = null;
	    SessionFactory factory = null;
	    EntityManager manager = null;

	    try {
	        factory = XJPA.getSessionFactory();
	        if (factory != null) {
	            manager = factory.createEntityManager();
	            manager.getTransaction().begin();

	            String jpql = "SELECT u FROM Users u WHERE u.id = :id OR u.email = :email";
	            TypedQuery<Users> query = manager.createQuery(jpql, Users.class);
	            query.setParameter("id", idOrEmail);
	            query.setParameter("email", idOrEmail);

	            user = query.getSingleResult();

	            manager.getTransaction().commit();
	        }
	    } catch (NoResultException e) {
	        user = null;
	    } catch (Exception e) {
	        if (manager != null && manager.getTransaction().isActive()) {
	            manager.getTransaction().rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        if (manager != null) {
	            manager.close();
	        }
	    }

	    return user;
	}


}
